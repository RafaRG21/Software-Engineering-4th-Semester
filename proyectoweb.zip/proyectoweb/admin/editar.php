<?php session_start(); ?>
<?php


//conexion a bbdd
$link = mysqli_connect('localhost', 'root', 'root', 'cursos');

//si existe "id" en la url 
if(isset($_GET['idlogin'])){
	$idlogin = $_GET['idlogin'];//le asigno una variable 
	$query1 = "SELECT * FROM login WHERE idlogin =".$idlogin; //cadena de consulta para el elemento $id
	if($result = mysqli_query($link, $query1)){ //si obtengo resultados ejecutando la consulta anterior
		while($user = mysqli_fetch_assoc($result)){ //asigno ese resultado a un array asociativo $user
			$nombre = $user['nombre']; //creo variables con los nombres de los campos de la tabla "users" 
			$correo = $user['correo'];
			$contrasenia = $user['contrasenia'];
		}
	}
    
    

}


if(isset($_POST['sw']) == 1){ //si se ha presionado el boton "Actualizar" 

	//cadena con la orden de actualizacion a la tabla "users" con los valores de los inputs enviados por POST
	$query2 = "UPDATE login SET nombre='".$_POST['nombre']."', correo='".$_POST['correo']."', contrasenia='".$_POST['contrasenia']."',' WHERE idlogin=".$_POST['idlogin'];
    
    
	if(mysqli_query($link, $query2)){ //si la consulta se ejecuta con exito
		echo "La informacion se actualizo con exito"; //mensaje de exito
		header('Location: index.php'); //redireccion a index.php
	}else{ //si ocurrio un error
		echo "Ocurrio un error al intentar actualizar"; //mensaje de error
	}
}

//cierro conexion a bbdd
mysqli_close($link);
?>
<!DOCTYPE html>
<html>
<head>
	<title>CRUD basico con PHP y MySQL</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div id="wrapper">
		<h3>Editar usuario</h3>
		<form action="editar.php" method="post">
			<label for="nombre">Nombre: </label><br />
			<input type="text" name="nombre" value="<?php if(isset($nombre)) echo $nombre; ?>" /><br /><br />

			<label for="correo">Email: </label><br />
			<input type="text" name="correo" value="<?php if(isset($correo)) echo $correo; ?>" /><br /><br />

			<label for="contrasenia">Contraseña: </label><br />
			<input type="text" name="contrasenia" value="<?php if(isset($contrasenia)) echo $contrasenia; ?>" /><br /><br />

			<input class="btn-success" type="submit" name="actualizar" value="Actualizar" /><br /><br />
			<a class="btn" href="index.php"><< Volver</a>
			
			<input type="hidden" name="sw" value="1" />
		</form>
	</div>
</body>
</html>