<?php
	//Realizamos la conexion a la BD: "cursos"
	$connection = mysqli_connect('localhost', 'root', 'root', 'cursos');

	// for testing connection
	if(!$connection) {
		echo 'Error de conexion a la BD...'. mysqli_connect_error();
		exit();
	}
	else
	echo 'conexion hecha';

?>

